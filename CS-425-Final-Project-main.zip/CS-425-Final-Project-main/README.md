# Final Project for CS 425: Database Organization
## Real Estate Management Application

Written by: Michael Kosinski, Raul Gandara, Howard Rovira

Important notes for setup:
- The code assumes you are logged into PostgreSQL with the user 'postgres' and the password 'password'. You will have to edit the password in your copy of the code to change that if your password is different.
- It also assumes the database the schema is loaded into is called 'FinalProject'
